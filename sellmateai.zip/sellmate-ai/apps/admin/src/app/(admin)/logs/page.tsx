'use client';

import { useEffect, useState } from 'react';
import { Badge, PageHeader } from '@/lib/ui';
import { DataTable, LoadMore, Toolbar, usePaged } from '@/lib/table';
import { formatDate } from '@/lib/format';

export default function LogsPage() {
  const [action, setAction] = useState('');
  const { items, nextCursor, loading, error, load } = usePaged<any>(
    (c) => `/admin/audit-logs?limit=40${action ? `&action=${encodeURIComponent(action)}` : ''}${c ? `&cursor=${c}` : ''}`,
  );

  useEffect(() => {
    load(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const color = (a: string) =>
    a.includes('FAILED') || a.includes('SUSPEND') || a.includes('DELETE')
      ? 'red'
      : a.includes('LOGIN') || a.includes('ACTIVATE')
        ? 'green'
        : 'blue';

  return (
    <div>
      <PageHeader title="سجلّ النظام (التدقيق)" subtitle="كل أحداث الأمان والإدارة عبر المنصّة" />
      <Toolbar search={action} onSearch={setAction} onSubmit={() => load(true)} />
      {error && <p className="mb-3 text-sm text-red-600">{error}</p>}

      <DataTable
        loading={loading}
        rows={items}
        empty="لا توجد سجلّات."
        columns={[
          { key: 'createdAt', header: 'الوقت', render: (l) => formatDate(l.createdAt) },
          { key: 'action', header: 'الحدث', render: (l) => <Badge color={color(l.action)}>{l.action}</Badge> },
          { key: 'actorEmail', header: 'المنفِّذ', render: (l) => l.actorEmail ?? '—' },
          {
            key: 'target',
            header: 'الهدف',
            render: (l) => (l.targetType ? `${l.targetType}` : '—'),
          },
          { key: 'ip', header: 'IP', render: (l) => <span className="text-xs text-slate-500">{l.ip ?? '—'}</span> },
        ]}
      />
      <LoadMore cursor={nextCursor} loading={loading} onMore={() => load(false, nextCursor)} />
    </div>
  );
}
